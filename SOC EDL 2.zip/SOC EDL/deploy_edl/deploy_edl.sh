#!/usr/bin/env bash
# =============================================================================
# deploy_edl.sh
# Deploy PAN-OS EDL files and nginx site configuration.
#
# Run as root or with sudo. Idempotent — safe to re-run on updates.
#
# Usage:
#   chmod +x deploy_edl.sh
#   sudo ./deploy_edl.sh
# =============================================================================
set -euo pipefail

# --- Configuration -----------------------------------------------------------
EDL_DIR="/var/www/edl"
NGINX_AVAILABLE="/etc/nginx/sites-available/edl-server.conf"
NGINX_ENABLED="/etc/nginx/sites-enabled/edl-server.conf"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

DOMAIN_EDL="${SCRIPT_DIR}/domain_edl.txt"
IP_EDL="${SCRIPT_DIR}/ip_edl.txt"
NGINX_CONF="${SCRIPT_DIR}/edl-server.conf"

# --- Colours -----------------------------------------------------------------
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# --- Preflight ---------------------------------------------------------------
info "Preflight checks..."

[[ $EUID -eq 0 ]] || error "Must run as root."

command -v nginx &>/dev/null || error "nginx not installed. Run: apt install nginx"

[[ -f "$DOMAIN_EDL" ]] || error "domain_edl.txt not found in ${SCRIPT_DIR}"
[[ -f "$IP_EDL"     ]] || error "ip_edl.txt not found in ${SCRIPT_DIR}"
[[ -f "$NGINX_CONF" ]] || error "edl-server.conf not found in ${SCRIPT_DIR}"

# Warn if IP allow-list is still commented out in nginx config
if grep -q '# allow 10\.' "$NGINX_CONF"; then
    warn "IP allow-list is commented out in edl-server.conf."
    warn "Restrict /edl/ to firewall management IPs before production use."
fi

# --- Create EDL document root ------------------------------------------------
info "Creating EDL directory: ${EDL_DIR}"
install -d -m 755 -o www-data -g www-data "${EDL_DIR}"

# --- Deploy EDL files --------------------------------------------------------
info "Deploying EDL files..."
install -m 644 -o www-data -g www-data "${DOMAIN_EDL}" "${EDL_DIR}/domain_edl.txt"
install -m 644 -o www-data -g www-data "${IP_EDL}"     "${EDL_DIR}/ip_edl.txt"

DOMAIN_COUNT=$(wc -l < "${EDL_DIR}/domain_edl.txt")
IP_COUNT=$(wc -l < "${EDL_DIR}/ip_edl.txt")
info "  domain_edl.txt : ${DOMAIN_COUNT} entries"
info "  ip_edl.txt     : ${IP_COUNT} entries"

# --- Deploy nginx site config ------------------------------------------------
info "Installing nginx site config..."
install -m 644 "${NGINX_CONF}" "${NGINX_AVAILABLE}"

if [[ ! -L "${NGINX_ENABLED}" ]]; then
    ln -s "${NGINX_AVAILABLE}" "${NGINX_ENABLED}"
    info "Site enabled: ${NGINX_ENABLED}"
else
    info "Site already enabled."
fi

# Disable default site if present (avoids port 80 conflict)
if [[ -L "/etc/nginx/sites-enabled/default" ]]; then
    warn "Removing default nginx site to avoid port 80 conflict."
    rm /etc/nginx/sites-enabled/default
fi

# --- Test and reload nginx ---------------------------------------------------
info "Testing nginx configuration..."
nginx -t || error "nginx config test failed. Fix errors above and retry."

info "Reloading nginx..."
systemctl reload nginx

# --- Smoke test --------------------------------------------------------------
info "Running smoke tests..."

BASE_URL="http://127.0.0.1"

smoke_check() {
    local label="$1" url="$2" expected_status="$3"
    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" "${url}")
    if [[ "$status" == "$expected_status" ]]; then
        info "  [PASS] ${label} → HTTP ${status}"
    else
        warn "  [FAIL] ${label} → expected HTTP ${expected_status}, got HTTP ${status}"
    fi
}

smoke_check "domain_edl.txt"  "${BASE_URL}/edl/domain_edl.txt"  "200"
smoke_check "ip_edl.txt"      "${BASE_URL}/edl/ip_edl.txt"      "200"
smoke_check "healthz"         "${BASE_URL}/healthz"             "200"
smoke_check "root (404)"      "${BASE_URL}/"                    "404"
smoke_check "dir listing"     "${BASE_URL}/edl/"                "403"

# --- Summary -----------------------------------------------------------------
HOST_IP=$(hostname -I | awk '{print $1}')
echo ""
info "Deployment complete."
echo ""
echo "  PAN-OS EDL Object URLs"
echo "  ──────────────────────────────────────────────────────────"
echo "  Domain EDL : http://${HOST_IP}/edl/domain_edl.txt"
echo "  IP EDL     : http://${HOST_IP}/edl/ip_edl.txt"
echo ""
echo "  Configure each as a separate EDL object in Panorama:"
echo "    Objects → External Dynamic Lists → Add"
echo "    Domain EDL : Type = Domain,     Source = URL above"
echo "    IP EDL     : Type = IP Address, Source = URL above"
echo ""
warn "Reminder: uncomment and configure the IP allow-list in"
warn "  ${NGINX_AVAILABLE}"
warn "to restrict EDL access to Panorama / firewall OOB management IPs."
echo ""
